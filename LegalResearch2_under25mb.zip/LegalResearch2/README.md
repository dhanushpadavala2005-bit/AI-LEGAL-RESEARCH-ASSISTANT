# Indian Legal Research Assistant

## Run locally

1. Install [Ollama for Windows](https://ollama.com/download/windows) and keep it running.
2. Download the free local model once: `ollama pull qwen3:4b-instruct` (about 2.5 GB).
3. Copy `.env.example` to `.env` if you want to customize the local Ollama address or model name. No API key or hosted-model account is needed.
4. Activate the same Python environment you use to run the app, then install dependencies: `python -m pip install -r requirements.txt`.
5. Start the app from that environment: `python -m streamlit run app.py`.

The generation model defaults to `qwen3:4b-instruct`, running locally through Ollama. It does not expire like hosted API model IDs, but needs enough memory and can run more slowly on a CPU-only computer. Change `OLLAMA_MODEL` in `.env` only if you install a different Ollama model.

## Optional NVIDIA Nemotron trial

The app can also use NVIDIA's currently listed free Nemotron endpoint without removing the Ollama path. Install the optional integration with `python -m pip install -r requirements-nvidia.txt`, then set these values in `.env`:

```dotenv
LLM_PROVIDER=nvidia
NVIDIA_API_KEY=your-nvidia-api-key
NVIDIA_MODEL=nvidia/nemotron-3.5-lightning-30b-a3b
```

Get an API key from NVIDIA's [Nemotron endpoint page](https://build.nvidia.com/nvidia/nemotron-3.5-lightning-30b-a3b), then restart Streamlit. To return to the local model, change `LLM_PROVIDER=ollama` and restart. The NVIDIA free endpoint is hosted and may have service availability or rate limits; the Ollama option remains local.

If startup reports `No module named 'torchvision'`, install/update the dependencies in the same environment used by Streamlit with `python -m pip install -r requirements.txt`. The requirements include `torchvision` for Transformers' image-processing imports, even though the legal assistant itself only uses text embeddings.
