from pathlib import Path
import os
from dotenv import load_dotenv

# -----------------------------
# Project Root
# -----------------------------
BASE_DIR = Path(__file__).resolve().parent

# -----------------------------
# Load Environment Variables
# -----------------------------
load_dotenv(BASE_DIR / ".env")

# -----------------------------
# Local Ollama model. Ollama runs on this computer; no hosted API key is needed.
# -----------------------------
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "ollama").strip().lower()
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")
NVIDIA_MODEL = os.getenv(
    "NVIDIA_MODEL", "nvidia/nemotron-3.5-lightning-30b-a3b"
)

# -----------------------------
# Paths
# -----------------------------
VECTORSTORE_PATH = BASE_DIR / "vectorstore"
DATA_PATH = BASE_DIR / "data"
METADATA_PATH = DATA_PATH / "metadata"

# -----------------------------
# Embedding Model
# (must match the model used to build the vectorstore - do not change
#  unless you rebuild the vectorstore)
# -----------------------------
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# -----------------------------
# Ollama LLM
# -----------------------------
# Small local model suitable for RAG and case-file Q&A.
LLM_MODEL = os.getenv("OLLAMA_MODEL", "qwen3:4b-instruct")
LLM_MAX_TOKENS = 600

# -----------------------------
# Retrieval
# -----------------------------
SEARCH_TYPE = "similarity" # Prefer the closest matching passages for precise legal answers.
TOP_K = 5                  # chunks sent to the LLM (was 3)
FETCH_K = 20               # candidates considered before MMR picks TOP_K
MMR_LAMBDA = 0.6           # 1.0 = pure relevance, 0.0 = pure diversity

# ~1200-char chunks, so 6500 fits 5 chunks. (The old 3000 limit silently
# dropped the 3rd chunk.)
MAX_CONTEXT_CHARS = 6500

# Max related landmark cases (from cases.csv) added to the prompt
MAX_CASES = 3
